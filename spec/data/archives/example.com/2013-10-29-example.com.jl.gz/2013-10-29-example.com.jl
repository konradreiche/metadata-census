{"repository":"example.com","type":"CKAN","date":"2013-10-29","count":1}
[{"id":"1e7455dc-8ca0-444b-be7e-db9c3a41ff8f","name": "example-dataset","resources": []}]
